let evenNumbers = numbers.filter { $0 % 2 == 0 }
// evenNumbers = [2, 4]