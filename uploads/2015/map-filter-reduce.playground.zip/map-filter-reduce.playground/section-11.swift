let someNumbers = [1, 2, 3, 4, 5]
let result = someNumbers.filter { $0 % 2 == 0 }.map { $0 + 10 }.reduce(0) { $0 + $1 }