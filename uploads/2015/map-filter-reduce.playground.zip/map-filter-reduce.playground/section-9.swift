let sum = numbers.reduce(0) { $0 + $1 }
// sum = 15