let multipliedNumbers = numbers.map { elem in
    return elem * 2
}
// multipliedNumbers = [2, 4, 6, 8, 10]